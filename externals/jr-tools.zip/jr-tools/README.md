jr-tools
========

Open source tools of MEG/EEG analyses based on [MNE-Python](https://github.com/kingjr/mne-python)

Installation
============

Clone this repository and install using setup.py:

```python setup.py develop --user```

You need an installation of [MNE-Python](https://github.com/dengemann/mne-python) and [Scikit-Learn](https://github.com/scikit-learn/scikit-learn) to use these tools.
