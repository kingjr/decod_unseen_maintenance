from .Figtodat import fig2data, fig2img
from .images2gif import writeGif, readGif
import Figtodat
